@extends('layouts.app')
@section('content')
<meta http-equiv="refresh" content="5;url=/home" />
Added to database! You will be redirected back in: <span id="seconds">5</span>.

 
<input type="hidden" name="_token" value="{{ csrf_token() }}">
@endsection