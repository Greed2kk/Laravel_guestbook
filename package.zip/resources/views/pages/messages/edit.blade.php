
@extends('index')

@section('content')

@include('_common._form')
<hr>
@stop