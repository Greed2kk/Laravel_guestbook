@extends('layouts.app')
@section('content')
<meta http-equiv="refresh" content="0;url=/home" />
Message edited! You will be redirected back in: <span id="seconds">5 sec</span>.

 
<input type="hidden" name="_token" value="{{ csrf_token() }}">
 @endsection