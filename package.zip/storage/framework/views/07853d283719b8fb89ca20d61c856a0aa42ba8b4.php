
<div class="messages" >
     
        <?php if(!$message->isEmpty()): ?>
         
            <?php $__currentLoopData = $message; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $messages): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
             
          <div class="p-3 mb-2 bg-success text-white">
                <div class="card-header">
                    <h5 class="card-title">
                        
                        <span><strong>Отправитель: </strong>#<?php echo $messages->id; ?>  
                             <span class="float-right"><strong>Время/дата: </strong><?php echo e($messages->created_at); ?></span>
                          <div class="media">
                              <img class="mr-3" src="<?php echo e(asset('images/'.$messages->email.'.png')); ?>" class="figure-img img-fluid rounded" alt="empty">
                              </div>
                           <div class="media-body">
    <h5 class="mt-0"><?php if(is_null($messages->email)): ?>
                            <?php echo e($messages->name); ?>

                            
                            <?php else: ?>
                            <?php echo e($messages->name); ?>

                            <a href="mailto::<?php echo e($messages->email); ?>"><?php echo e($messages->email); ?></a>
                            
                            <?php endif; ?>
                        </span></h5>
                          </div>
                    </h5>
                </div>
                <div class="card-body">  
                    <div class="alert alert-dark"> 
         <p><strong>Сообщение:</strong></p> <p class="lead"><?php echo e($messages->message); ?></p>
                  </div>
                    
                    <?php if(Auth::user()->email === $messages->email): ?>
                    
                    <div class="float-left">
                        
                        <form method="POST" id="id-editm" action="<?php echo e(route('editm', ['id' => $messages->id, 'message' => $messages->message])); ?>" aria-label="<?php echo e(__('editm')); ?>" value="$s=$messages->id">
                            <?php echo e(csrf_field()); ?>

                        <button class="btn btn-info">
                            <i class="material-icons">build</i>                        
                        </button>
                        </form>

                        <form method="POST" id="id-delete" action="<?php echo e(route('del', ['id' => $messages->id])); ?>" aria-label="<?php echo e(__('del')); ?>">
                            <?php echo e(csrf_field()); ?>

                        <button class="btn btn-danger">
                            <i class="material-icons">delete</i>                        
                        </button>
                        </form>
                        
                        <?php endif; ?>
                        
                    </div>
                    <br>
                   </div>
                </div>
            <br>
           <hr/>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <nav aria-label="Page navigation example">
                    <ul class="pagination justify-content-center">
                        <?php echo e($message->links()); ?>

                    </ul>
                </nav>
              <?php else: ?> 
               <p><strong>Сообщений нет!</strong></p>
                <?php endif; ?>
        </div>
         
    

