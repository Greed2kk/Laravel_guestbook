<?php $__env->startSection('content'); ?>
     
        <?php echo $__env->make('_common._form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<hr>
    
<div class="alert alert-secondary">
        <div class="text-left"><b>Всего сообщений:</b> <i class="badge badge-pill badge-danger"><?php echo e($count); ?></i></div>
        </div>
       <hr>

        <?php echo $__env->make('pages.messages._item', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>