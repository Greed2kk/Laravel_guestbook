<?php $__env->startSection('content'); ?>
<meta http-equiv="refresh" content="5;url=/home" />
Added to database! You will be redirected back in: <span id="seconds">5</span>.

 
<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>