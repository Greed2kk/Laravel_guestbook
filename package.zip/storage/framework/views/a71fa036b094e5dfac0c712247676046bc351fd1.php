<?php $__env->startSection('content'); ?>
<div class="container">
<form method="POST" id="id-form_messages" action="<?php echo e(route('editadd', ['id' => $_GET['id']])); ?>" aria-label="<?php echo e(__('editadd')); ?>" >
<?php echo e(csrf_field()); ?>


        <div class="form-group">
            <div class="alert alert-primary" role="alert">
            <label for="name">№ записи : </label>
            <?php echo $_GET['id']; ?>   
            </div>
        </div>

        <div class="form-group">
            <label for="name">Имя: </label>
            <span class="badge badge-info"> <?php echo e(Auth::user()->name); ?> </span>   
        </div>

        <div class="form-group">
            <label for="email">E-mail:</label>
            <span class="badge badge-pill badge-secondary"> <?php echo e(Auth::user()->email); ?>  </span>  
        </div>

        <div class="form-group">
            <label for="message">Сообщение:*</label>
            <textarea autofocus class="form-control" rows="5"  name="message" cols="50"
                      id="message"><?php echo $_GET['message']; ?></textarea>
        </div>

        <div class="form-group">
            <input class="btn btn-success" type="submit" value="Добавить">
            <input type="button" class="btn btn-outline-danger" onclick="history.back();" value="Назад"/>
            <button type="reset" class="btn btn-danger">Очистить</button>
        </div>
    
</form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>